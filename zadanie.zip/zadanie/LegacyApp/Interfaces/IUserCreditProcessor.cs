﻿namespace LegacyApp
{
    public interface IUserCreditProcessor
    {
        void ProcessCredit(User user, Client client);
    }
}