﻿namespace LegacyApp
{
    public interface IUserCreditServiceFactory
    {
        IUserCreditService Create();
    }
}